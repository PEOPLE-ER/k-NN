# -*- coding: utf-8 -*-
"""
k Nearest Neighbour Regression
for Earth Observation image based prediction of forest variables

Produced by VTT in the PEOPLE_ER project
funded by ESA 

License: CC BY-SA 4.0 
    
"""
import numpy as np
import matplotlib.pyplot as plt
import sklearn.metrics as metrics
from sklearn.preprocessing import StandardScaler
import pandas as pd
import seaborn as sns

import rasterio as rast
import csv


class KNNRegressor:
    def __init__(self, n_neighbors=5):
        self.n_neighbors = n_neighbors
        self.X = None
        self.y = None
    
    def fit(self, X, y):
        self.X = X
        self.y = y
    
    def predict(self, X):
        predictions = []
      

        for x in X:
            distances = np.linalg.norm(self.X - x, axis=1)
            indices = np.argsort(distances)[:self.n_neighbors]
            k_nearest_targets = self.y[indices]
            k_nearest_distances = distances[indices]

            weights = 1 / (k_nearest_distances + 1e-7)  
            weighted_targets = k_nearest_targets * weights[:, np.newaxis]

            pred = np.sum(weighted_targets, axis=0) / np.sum(weights)

            predictions.append(pred)
           
            
        return np.array(predictions)#, np.array(variance)

def read_params_from_keyboard():

    # Initialize an empty list to store input lists
    trainfname = []
    testfname =[]
    EO_features = []
    target_features = []

    # Read lists from the keyboard and save them into corresponding variables
    trainfname = input("Enter a name of csv-file with training data: ")
    testfname =input("Enter a name of csv-file with testing data: ")
    EO_features = input("Enter a list of EO features to be used in forest variable prediction: ").split()
    target_features = input("Enter a list of target variables to be predicted: ").split()
    inputEOimage_name = input("Enter a full name of input EO image: ")
    output_image_name = input("Enter a full name of output predictiona image/map: ")
    knum = int(input("Enter numbe rof neighbors k: "))
        
    return trainfname, testfname, EO_features, target_features, inputEOimage_name, output_image_name, knum



def read_settings_from_csv(file_path):
    settings = {}
    with open(file_path, newline='') as csvfile:
        reader = csv.DictReader(csvfile)
        for row in reader:
            parameter_name = row['parameter_name']
            parameter_value = row['parameter_value']
            settings[parameter_name] = parameter_value
    return settings

##################


csv_file = input("Give name of settings-file or press Enter to continue to keyboard input: ")

if csv_file:
    settings = read_settings_from_csv(csv_file)
    print('\n******read-in parameters******')
    for parameter, value in settings.items():
        print(f"{parameter}: {value}")
    trainfname=settings.get('trainfname')
    testfname=settings.get('testfname')
    EO_features=settings.get('EO_features').split()
    target_features=settings.get('target_features').split()
    image_name=settings.get('inputEOimage_name')
    outfile_name=settings.get('output_image_name')
    knum=int(settings.get('neighbors'))
else:
    # No settings filename provided, keyboard input
    print("Proceeding to keyboard input")
    trainfname, testfname, EO_features, target_features, image_name,outfile_name,knum = read_params_from_keyboard();


print("\nPress any key to continue...")
input()


df_data=pd.read_csv(trainfname,delimiter=",",index_col=False)
df_X=df_data[EO_features]
df_Y=df_data[target_features]

#prepare numpy arrays for modeling
y_V=df_Y.to_numpy()
X=df_X.to_numpy()

#normalize the data
scaler = StandardScaler().fit(X)
X = scaler.transform(X)

neigh= KNNRegressor(n_neighbors=knum)

neigh.fit(X, y_V)

###############################################################################
df_data=pd.read_csv(testfname,delimiter=",",index_col=False)
df_aX=df_data[EO_features]
df_aY=df_data[target_features]

#prepare numpy arrays for modeling
ay_V=df_aY.to_numpy()
aX=df_aX.to_numpy()


aX = scaler.transform(aX)

ay_p = neigh.predict(aX)


#choose variable for accuracy metrics calculation, default is 0-th in order
ev=0 
refvar=ay_V[:,ev]
predvar=ay_p[:,ev]
mse = metrics.mean_squared_error(refvar,predvar)
bias=np.mean(predvar-refvar)
rmse = np.sqrt(mse)
rmsep=rmse/np.mean(refvar)*100
r2 = metrics.r2_score(refvar,predvar)

print("Accuracy metrics for target variable ",target_features[ev])
print("RMSE:", rmse)
print("RMSEp:", rmsep)
print("Bias:", bias)
print("R-Squared:", r2)


#two-dimensional density scatter plot
sns.set(style="white", rc={"axes.facecolor": (0, 0, 0, 0)})
plt.figure(figsize=(8, 6))
plotscatter = pd.DataFrame({'X': refvar, 'Y': predvar})
sns.scatterplot(x='X', y='Y', data=plotscatter, s=50, color=".3", marker='o')

plt.ylabel('predicted values')
plt.xlabel('reference values')
plt.xlim([0, np.max(refvar)])
plt.ylim([0, np.max(predvar)])
plt.grid(True)


#########################################################


print("Now reading the input EO image.....")
dset = rast.open(image_name)
#read in the pixels
imbands = dset.read()
bands=imbands[:,:,:] #EO image bands and their order should fully correspond to "EO_features"
     
tab = bands.reshape(bands.shape[0], (bands.shape[1]*bands.shape[2]))
tabX=np.transpose(tab)
tabX = np.nan_to_num(tabX)
    
   


print("Scaling the input image features.....")  
tabXp = scaler.transform(tabX)

print("Predicting .....")        
tab_p=neigh.predict(tabXp)

parr=np.transpose(tab_p)
parr=parr.reshape(len(target_features),bands.shape[1],bands.shape[2])

#do the prediction - create the map

print("Writing out the resulting file.....")
with rast.Env():
  # Write an array as a raster band to a new file. 
      profile = dset.profile
        
      profile.update(count=len(target_features))
      
      with rast.open(outfile_name, 'w', **profile) as dst:
          for band_nr in range(0,len(target_features)):
                dst.write(parr[band_nr].astype(rast.float32), band_nr+1)
          dst.descriptions = target_features
          dst.close()

